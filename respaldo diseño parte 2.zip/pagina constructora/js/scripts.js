$(window).scroll(function() {
   var hT = $('#design').offset().top,
       hH = $('#design').outerHeight(),
       wH = $(window).height(),
       wS = $(this).scrollTop();
    //console.log((hT-wH) , wS);
   if (wS > (hT+hH-wH)){




    $(document).ready(function(){
var li=[$('#design'),$('#design2'),$('#design3'),$('#design4')];
$.each(li,function(k,val){

var value=val.attr('data-nums');
 var options = {};
   options ['toValue'] = value;
    options ['duration'] = 5000;
val.numerator(options);
})
  


  });
  



   }
});


