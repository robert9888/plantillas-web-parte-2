$(document).ready(function(){
        		$('.cl1-1').animate({width:'90%'},3000);
        		$('.cl1-2').animate({width:'75%'},3000);
        		$('.cl1-3').animate({width:'50%'},3000);
        		$('.cl1-4').animate({width:'70%'},3000);
        		$('.cl1-5').animate({width:'45%'},3000);
});